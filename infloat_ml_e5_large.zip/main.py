from starlette.requests import Request

from ray import serve
from sentence_transformers import SentenceTransformer


# @serve.deployment(placement_group_bundles=[{"num_cpus": 1, "num_gpus": 0}],placement_group_strategy="STRICT_PACK", max_concurrent_queries=1000, num_replicas=10, ray_actor_options={"num_cpus": 0, "num_gpus": 0.1}, name="sentence-embedding-gpu")
@serve.deployment(num_replicas=1, ray_actor_options={"num_cpus": 2, "num_gpus": 0.5}, name="embedding-cpu")
class SentenceTransformerModel:
    def __init__(self):
        self.model = SentenceTransformer('intfloat/multilingual-e5-large')
        self.model.cuda()

    async def __call__(self, request: Request):
        sentences = await request.json()
        return self.model.encode(sentences["text"])

embedding_app = SentenceTransformerModel.bind()

from starlette.requests import Request

from ray import serve
from FlagEmbedding import FlagReranker
# Pip install flagEmbedding peft

# @serve.deployment(placement_group_bundles=[{"num_cpus": 1, "num_gpus": 0}],placement_group_strategy="STRICT_PACK", max_concurrent_queries=1000, num_replicas=10, ray_actor_options={"num_cpus": 0, "num_gpus": 0.1}, name="sentence-embedding-gpu")
@serve.deployment(  route_prefix="/rerank",
                    num_replicas=6,
                    ray_actor_options={"num_gpus": 0.15},
                    name="Reranker-GPU",
                    placement_group_strategy="STRICT_SPREAD",
                    placement_group_bundles=[{"CPU":1,"GPU":0.15}]
                  )
class FlagRerankerModel:
    def __init__(self):
        self.model_reranker = FlagReranker('BAAI/bge-reranker-v2-m3',
                                           use_fp16=True,
                                           device="cuda")
        # self.model.cuda()

    async def __call__(self, request: Request):
        data = await request.json()
        max_length= 512 if data.get("max_length") == None else data["max_length"]
        batch_size = 256 if data.get("batch_size") == None else data["batch_size"]
        return self.model_reranker.compute_score(data.get("content"), normalize=True, max_length=max_length, batch_size=batch_size)

reranker_app = FlagRerankerModel.bind()

from starlette.requests import Request

from ray import serve
from sentence_transformers import SentenceTransformer
from sympy import false


# @serve.deployment(placement_group_bundles=[{"num_cpus": 1, "num_gpus": 0}],placement_group_strategy="STRICT_PACK", max_concurrent_queries=1000, num_replicas=10, ray_actor_options={"num_cpus": 0, "num_gpus": 0.1}, name="sentence-embedding-gpu")
@serve.deployment(  route_prefix="/embed",
                    num_replicas=4,
                    ray_actor_options={"num_gpus": 0.25},
                    name="Reranker-GPU",
                    placement_group_strategy="SPREAD",
                    placement_group_bundles=[{"CPU":1,"GPU":0.25}],
                    max_replicas_per_node=2,
                    max_ongoing_requests=150,
                  )
class SentenceTransformerModel:
    def __init__(self):
        self.model = SentenceTransformer('intfloat/multilingual-e5-large')
        self.model.cuda()

    async def __call__(self, request: Request):
        data = await request.json()
        normalize_embeddings = data.get("normalize_embeddings", False)
        batch_size = data.get("batch_size", 32)
        convert_to_numpy = data.get("convert_to_numpy", False)
        convert_to_tensor = data.get("convert_to_tensor", False)
        show_progress_bar = data.get("show_progress_bar", False)

        return self.model.encode(data.get("inputs"),
                                 normalize_embeddings=normalize_embeddings,
                                 batch_size=batch_size,
                                 convert_to_numpy = convert_to_numpy,
                                 convert_to_tensor= convert_to_tensor,
                                 show_progress_bar=show_progress_bar
                                 )

embedding_app = SentenceTransformerModel.bind()

# Vector Index Retriever
from llama_index.core import VectorStoreIndex
from llama_index.core.chat_engine.types import ChatMode
from llama_index.core.llms import ChatMessage
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.vector_stores.types import VectorStoreQueryMode
from llama_index.vector_stores.milvus import MilvusVectorStore

from embedding_model.embedding_model import embed_model, model_rerank
from functions.templating import clean_and_format_messages, convert_to_chat_messages
# ************End of Vector Index Retriever *************
from sparse_embedding_function.main import SparseEmbeddingFunction


# from llm_deployments.gpt4o import llm
# from llama_index.core.postprocessor import SentenceTransformerRerank

#cross-encoder/ms-marco-MiniLM-L-2-v2
# model_rerank = SentenceTransformerRerank(model="BAAI/bge-reranker-large", top_n=3,
#                                    keep_retrieval_score=True, device=os.getenv("DEVICE"))


def chat_responder(query_request, vector_db_uri,  custom_llm, rerank=model_rerank):
    # This function is used to respond to chat messages
    # It is called by the chat_listener function in the same file
    # It uses the chatbot API to generate a response to the chat message
    # It then sends the response to the chat
    # llm = set_llm(query_request.deployment)
    DEFAULT_SYSTEM_PROMPT = """
                    "Here are the relevant documents for the context:\n"
                    "{context_str}"
                    "You are a chatbot, able to have normal interactions"````
                    "\nInstruction: Use the previous chat history, relevant documents, or the context above,"
                    "to interact and help the user. "
                    "do not respond outside the context of the document and respond that you `do not have relevance of the query.`"
                    """
    # print(vector_db_uri)
    vector_store = MilvusVectorStore(
        dim=1024,
        token="root:Milvus",
        uri=vector_db_uri,
        enable_sparse=True,
        sparse_embedding_function=SparseEmbeddingFunction(),
        hybrid_ranker="RRFRanker",
        hybrid_ranker_params={"k": 60},
        collection_name=query_request.collection_name,
    )
    index = VectorStoreIndex.from_vector_store(vector_store=vector_store,
                                               embed_model=embed_model,
                                               show_progress=True)

    # Future: Implement Filters for the query, based on the metadata
    # filters = MetadataFilters(
    #     filters=[
    #         # MetadataFilter(key="email", operator=FilterOperator.EQ, value="sundeep.paluru@freshworks.com")
    #         MetadataFilter(key="email", operator=FilterOperator.EQ, value="vidhyasimhan.j@freshworks.com")
    #         # ExactMatchFilter(key="email", value="sundeep.paluru@freshworks.com")
    #     ]
    # )
    # retriever = index.as_retriever()
    retriever = VectorIndexRetriever(
        index=index,
        similarity_top_k=2,
        # filters=filters,
        vector_store_query_mode=VectorStoreQueryMode.HYBRID,
        # VectorStoreQueryMode.SPARSE/SEMANTIC_HYBRID is not supported
        embed_model=embed_model,
        node_postprocessors=[rerank],
        sparse_top_k=4,
        verbose=False,
    )
    # custom_llm = set_llm(query_request.deployment)
    print(custom_llm)
    # Get the chat engine
    chat_engine = index.as_chat_engine(chat_mode=ChatMode.CONDENSE_PLUS_CONTEXT,
                                       query_engine=RetrieverQueryEngine(retriever),
                                       # response_synthesizer=response_synthesizer,
                                       llm= custom_llm,
                                       prefix_messages=[ChatMessage(role="system",
                                                                    content=DEFAULT_SYSTEM_PROMPT)
                                                        ],
                                       )


    # Get the chatbot response
    formatted_messages = clean_and_format_messages(query_request.messages)
    user_query = formatted_messages[-1]['content']
    previous_messages = formatted_messages[:-1]
    chat_history = convert_to_chat_messages(previous_messages)

    # response = chat_engine.chat(message=user_query, chat_history=chat_history)
    response = chat_engine.chat(message=user_query, chat_history=chat_history)
    # Send the chatbot response to the chat
    # for r in response.response:
    #     return r
    return response.response
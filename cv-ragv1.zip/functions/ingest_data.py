# ************Ingestion Pipeline Llama Index*************
from llama_index.core import SimpleDirectoryReader
# from llama_index.core.extractors import TitleExtractor
# from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.node_parser import SentenceSplitter
from llama_index.vector_stores.milvus import MilvusVectorStore
from pymilvus import MilvusClient
from s3fs import S3FileSystem
from embedding_model.embedding_model import embed_model
from sparse_embedding_function.main import SparseEmbeddingFunction


# import timeit
# from multiprocessing import set_start_method
# from llama_index.embeddings.huggingface import HuggingFaceEmbedding
#
# #******************* END *********************************
#
# def create_huggingface_embedding():
#     return HuggingFaceEmbedding(
#         model_name="BAAI/bge-m3", trust_remote_code=True,
#     )

def ingest_data(collection_request, vector_db_uri):
    collection_name = collection_request.collection_name
    client = MilvusClient(uri=vector_db_uri)
    s3_documents = SimpleDirectoryReader(
        input_dir=collection_request.s3_path,
        fs=S3FileSystem(),
        recursive=True,
    )
    if not client.has_collection(collection_name):
        documents = s3_documents.load_data(show_progress=True)
        vector_store = MilvusVectorStore(
            dim=1024,
            token="root:Milvus",
            uri=vector_db_uri,
            enable_sparse=True,
            sparse_embedding_function=SparseEmbeddingFunction(),
            hybrid_ranker="RRFRanker",
            hybrid_ranker_params={"k": 60},
            collection_name=collection_name,
            overwrite=True,
        )
        # storage_context = StorageContext.from_defaults(vector_store=vector_store)
        # VectorStoreIndex.from_documents(documents=documents,
                                        # vector_store=vector_store, show_progress=True)
        parser = SentenceSplitter(chunk_size=1024, chunk_overlap=10, include_metadata=True, include_prev_next_rel=True)
        nodes = parser.get_nodes_from_documents(documents, show_progress=True)
        # VectorStoreIndex.from_documents(documents=documents,vector_store=vector_store, show_progress=True,
        #                                 transformations=[
        #                                     SentenceSplitter(chunk_size=1024, chunk_overlap=10, include_metadata=True,
        #                                                      include_prev_next_rel=True),
        #                                         embed_model
        #                                     ]
        #                                 )
        # vector_store=vector_store, show_progress=True)


        pipeline = IngestionPipeline(
            transformations=[
                embed_model
            ],
            vector_store=vector_store,
        )
        pipeline.run(nodes=nodes, show_progress=True)
        return  f"Ingestion completed successfully {collection_name}"

    if client.has_collection(collection_name):
        documents = s3_documents.load_data(show_progress=True)
        vector_store = MilvusVectorStore(
            dim=1024,
            token="root:Milvus",
            uri=vector_db_uri,
            enable_sparse=True,
            sparse_embedding_function=SparseEmbeddingFunction(),
            hybrid_ranker="RRFRanker",
            hybrid_ranker_params={"k": 60},
            collection_name=collection_name,
            overwrite=True,
        )
        parser = SentenceSplitter(chunk_size=1024, chunk_overlap=10, include_metadata=True,
                                  include_prev_next_rel=True)
        nodes = parser.get_nodes_from_documents(documents, show_progress=True)
        pipeline = IngestionPipeline(
            transformations=[
                embed_model
            ],
            vector_store=vector_store,
        )
        pipeline.run(nodes=nodes, show_progress=True)
        return f"Ingestion completed successfully {collection_name}"
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.readers.s3 import S3Reader


def load_data_from_s3(s3_path: str):
    loader = S3Reader(bucket=s3_path)
    return loader.load_data()


def clean_and_format_messages(messages):
    cleaned_messages = []
    for message in messages:
        cleaned_content = ' '.join(message['content'].split())
        cleaned_messages.append({
            "role": message['role'],
            "content": cleaned_content
        })
    return cleaned_messages


def convert_to_chat_messages(formatted_messages):
    role_mapping = {
        'system': MessageRole.SYSTEM,
        'user': MessageRole.USER,
        'assistant': MessageRole.ASSISTANT
    }
    chat_messages = [
        ChatMessage(role=role_mapping[msg['role']], content=msg['content'])
        for msg in formatted_messages
    ]
    return chat_messages

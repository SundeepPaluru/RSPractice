# ************Ingestion Pipeline Llama Index*************
from llama_index.core.node_parser import SentenceSplitter
# from llama_index.core.extractors import TitleExtractor
# from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.ingestion import IngestionPipeline
from llama_index.vector_stores.milvus import MilvusVectorStore
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from pymilvus import MilvusClient
from llama_index.core import VectorStoreIndex,StorageContext

from embedding_model.embedding_model import embed_model
from functions.templating import load_data_from_s3
from sparse_embedding_function.main import SparseEmbeddingFunction
# import timeit
# from multiprocessing import set_start_method
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

#******************* END *********************************

def update_ingest_data(collection_request, vector_db_uri):
    collection_name = collection_request.collection_name
    client = MilvusClient(uri=vector_db_uri)
    if client.has_collection(collection_name):
        documents = load_data_from_s3(collection_request.s3_path)
        vector_store = MilvusVectorStore(
            dim=1024,
            token="root:Milvus",
            uri=vector_db_uri,
            # enable_sparse=True,
            # sparse_embedding_function=SparseEmbeddingFunction(),
            hybrid_ranker="RRFRanker",
            hybrid_ranker_params={"k": 60},
            collection_name=collection_name,
            overwrite=True,
        )
        # storage_context = StorageContext.from_defaults(vector_store=vector_store)
        # VectorStoreIndex.from_documents(documents=documents,
                                        # vector_store=vector_store, show_progress=True)
        pipeline = IngestionPipeline(
            transformations=[
                SentenceSplitter(chunk_size=1024, chunk_overlap=11, include_metadata=True, include_prev_next_rel=True),
                embed_model,
            ],
            vector_store=vector_store,
        )
        pipeline.run(documents=documents, show_progress=True)
        # response = pipeline.run(show_progress=True, num_workers=2)
        # obj_pipeline = ingest_data(documents, collection_name, self.vector_store, Settings.embed_model)
        # obj_pipeline.run(show_progress=True)

        return  f"Ingestion completed successfully {collection_name}"

import asyncio
import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
# from llama_index.core import VectorStoreIndex, StorageContext, Settings
from llama_index.core import Settings
from pydantic import BaseModel
from pymilvus import MilvusClient
from ray import serve

from embedding_model.embedding_model import embed_model
# from embedding_model.embedding_model import embed_model
# from sparse_embedding_function.main import EMBEDDING_MODEL
from functions.chat_responder import chat_responder
from functions.ingest_data import ingest_data
from llm_deployments.all_llms import set_llm
from llm_deployments.gpt4o import llm

# Metadata Filters
# from llama_index.core.vector_stores import (
#     MetadataFilter,
#     MetadataFilters,
#     FilterOperator
# )
# ************End of Filters *************
# Vector Index Retriever
# ************End of Vector Index Retriever *************


# FastAPI app
app = FastAPI()

Settings.llm = llm
Settings.embed_model = embed_model
# Load the environment variables
vector_db_uri = os.getenv("MILVUS_URI")

class CollectionRequest(BaseModel):
    collection_name: str
    s3_path: str


class QueryRequest(BaseModel):
    messages: list
    collection_name: str
    deployment: str


@serve.deployment(num_replicas=1, ray_actor_options={"num_cpus": 2, "num_gpus": 0})
@serve.ingress(app)
class RagAssistantDeployment:
    def __init__(self):
        load_dotenv()
        self.loop = asyncio.get_running_loop()
        # Initialize the Milvus client
        self.client = MilvusClient(uri=vector_db_uri)

    @app.post("/create_index/")
    async def create_index(self, collection_request: CollectionRequest):
        if not self.client.has_collection(collection_request.collection_name):
            ingest_data(collection_request, vector_db_uri)
            return {
                "message": f"Index created successfully {collection_request.collection_name}"
            }
        else:
            raise HTTPException(status_code=400, detail="Collection already exists")

    @app.post("/update_index/")
    async def update_index(self, collection_request: CollectionRequest):
        if self.client.has_collection(collection_request.collection_name):
            ingest_data(collection_request, vector_db_uri)
            return {
                "message": f"Index created successfully {collection_request.collection_name}"
            }
        else:
            raise HTTPException(status_code=400, detail="Collection already exists")


    @app.post("/query_index/")
    async def query_index(self, query_request: QueryRequest):
        custom_llm = set_llm(query_request.deployment)
        try:
            response = chat_responder(query_request, vector_db_uri, custom_llm)
            return {
                "response": response
            }

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"An error occurred while querying the index: {str(e)}")


# Bind the deployment to Ray Serve
milvus_indexer = RagAssistantDeployment.bind()
from llama_index.llms.azure_openai import AzureOpenAI

from llama_index.llms.openllm import OpenLLM

AZURE_MODEL_LIST = ["gpt-4o-2024-05-13", "gpt-4o-2024-08-06", "gpt-4o-mini-2024-07-18"]
def set_llm(deployment: str):
    if deployment in AZURE_MODEL_LIST:
        llm = AzureOpenAI(
            model=deployment,
            temperature=0.0,
            engine=deployment,
            max_tokens=8000,
        )
        # llm = OpenLLM(
        #     api_base="http://mistral7b.cloudverse.freshworkscorp.com/v1/",
        #     model="mistralai/Mistral-7B-Instruct-v0.2",
        #     api_key="na",
        #     max_tokens=8000,
        # )
        return llm
    if deployment == "Mistral-7B" :
        llm = OpenLLM(
            api_base="http://mistral7b.cloudverse.freshworkscorp.com/v1/",
            model="mistralai/Mistral-7B-Instruct-v0.2",
            api_key="na",
            max_tokens=8000,
        )
        return llm


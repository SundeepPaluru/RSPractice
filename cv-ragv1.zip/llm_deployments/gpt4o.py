from dotenv import load_dotenv
from llama_index.llms.azure_openai import AzureOpenAI

load_dotenv("../.env")
llm = AzureOpenAI(
    model_name="gpt-4o",
    temperature=0.0,
    engine="gpt-4o"
            )
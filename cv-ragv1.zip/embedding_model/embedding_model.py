import os

from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from FlagEmbedding import BGEM3FlagModel

# cross-encoder/ms-marco-MiniLM-L-2-v2
# BAAI/bge-reranker-large
model_rerank = SentenceTransformerRerank(model="cross-encoder/ms-marco-MiniLM-L-2-v2", top_n=3,
                                   keep_retrieval_score=True, device="cpu")
embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-m3",
    # embed_batch_size=10,
    trust_remote_code=True,
    device=os.getenv("DEVICE"),
)
# BAAI/bge-m3
# BAAI/bge-large-en
# BAAI/bge-large-en-v1.5
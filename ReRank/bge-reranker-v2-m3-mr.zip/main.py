from starlette.requests import Request
import os
from ray import serve
from FlagEmbedding import FlagReranker
# Pip install flagEmbedding peft
import ray
import requests
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict, Optional
from ray import serve
import asyncio


class Item(BaseModel):
    content: List[List[str]]
    max_length: Optional[int] = 512
    batch_size: Optional[int] = 256


app = FastAPI()


# @serve.deployment(placement_group_bundles=[{"num_cpus": 1, "num_gpus": 0}],placement_group_strategy="STRICT_PACK", max_concurrent_queries=1000, num_replicas=10, ray_actor_options={"num_cpus": 0, "num_gpus": 0.1}, name="sentence-embedding-gpu")
@serve.deployment(
    ray_actor_options={"num_cpus": 2, "num_gpus": 0.5},
    name="Reranker-GPU",
    placement_group_strategy="SPREAD",
    placement_group_bundles=[{"CPU": 2, "GPU": 0.5}],
    # max_replicas_per_node=2,
    max_ongoing_requests=100,
    autoscaling_config={
        "target_ongoing_requests": 200,
        "min_replicas": 2,
        "initial_replicas": 2,
        "max_replicas": 6,
        "upscale_delay_s": 3,
        "downscale_delay_s": 60,
        "upscaling_factor": 0.3,
        "downscaling_factor": 0.3,
        "metrics_interval_s": 2,
        "look_back_period_s": 10
    }
)
@serve.ingress(app)
class FlagRerankerModel:
    def __init__(self):
        # os.environ["CUDA_VISIBLE_DEVICES"]=0
        # os.environ["OMP_NUM_THREADS"] = "100"
        self.model_reranker = FlagReranker('BAAI/bge-reranker-v2-m3',
                                           use_fp16=True,
                                           device="cuda")

    @app.post("/rerank")
    async def rerank(self, request: Item):
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self.model_reranker.compute_score,
                                            request.content,
                                            True,
                                            request.max_length,
                                            request.batch_size)
        return result


reranker_app = FlagRerankerModel.bind()

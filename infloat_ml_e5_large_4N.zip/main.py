from starlette.requests import Request
from typing import Dict
from ray import serve
from sentence_transformers import SentenceTransformer
from ray.serve import Application

# @serve.deployment(placement_group_bundles=[{"num_cpus": 1, "num_gpus": 0}],placement_group_strategy="STRICT_PACK", max_concurrent_queries=1000, num_replicas=10, ray_actor_options={"num_cpus": 0, "num_gpus": 0.1}, name="sentence-embedding-gpu")
@serve.deployment(  route_prefix="/embed",
                    num_replicas=4,
                    ray_actor_options={"num_gpus": 0.25},
                    name="Embeddings-GPU",
                    # placement_group_strategy="SPREAD",
                    # placement_group_bundles=[{"CPU":1,"GPU":0.25}],
                    max_replicas_per_node=2,
                    # max_ongoing_requests=5,
                  )
class SentenceTransformerModel:
    def __init__(self):
        self.model = SentenceTransformer('intfloat/multilingual-e5-large')
        self.model.cuda()

    async def __call__(self, request: Request):
        try:
            data = await request.json()
            normalize_embeddings = data.get("normalize_embeddings", False)
            batch_size = data.get("batch_size", 32)
            show_progress_bar = data.get("show_progress_bar", False)
            print(data)
            return self.model.encode(sentences=data.get("inputs"),
                                     normalize_embeddings=normalize_embeddings,
                                     batch_size=batch_size,
                                     show_progress_bar=show_progress_bar
                                     )
        except Exception as e:
            print(e)
            return {"Error Message": f"An error occurred while processing the request{e}"}

embedding_app = SentenceTransformerModel.bind()
